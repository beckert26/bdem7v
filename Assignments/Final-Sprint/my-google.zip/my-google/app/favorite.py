from flask_login import UserMixin

from db import get_db


class Favorite(UserMixin):
    def __init__(self, email, link):
        self.email = email
        self.link=link

    @staticmethod
    def get(email):
        db = get_db()
        favorite = db.execute(
            "SELECT * FROM favorite WHERE email = ?", (email,)
        ).fetchone()
        if not favorite:
            return None

        favorite = Favorite(
            email=favorite[0], link=favorite[1]
        )
        return favorite

    @staticmethod
    def create(email, link):
        db = get_db()
        db.execute(
            "INSERT INTO favorite (email, link)"
            " VALUES (?, ?)",
            (email, link),
        )
        db.commit()
    def delete():
        db=get_db()
        db.execute("Delete from favorite")
        db.commit()

    def getAll(email):
        links=[]
        db = get_db()
        for row in db.execute("SELECT link FROM favorite WHERE email = ?", (email,)).fetchall():
            links.append(row[0])

        return links
